package com.example.navegacao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
